function addToDisplay(value) {
    document.getElementById('display').value += value; // Add the clicked button's value to the display
}

function clearDisplay() {
    document.getElementById('display').value = ''; // Clear the display
}

function calculate() {
    let displayValue = document.getElementById('display').value; // Get the value in the display
    let result = eval(displayValue); // Evaluate the mathematical expression
    document.getElementById('display').value = result; // Show the result on the display
}
